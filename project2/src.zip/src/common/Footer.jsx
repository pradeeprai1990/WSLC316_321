import React from 'react'

export default function Footer() {
  return (
    <div>
        <h1>Welcome to Footer Section</h1>
    </div>
  )
}
